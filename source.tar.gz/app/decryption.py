def xor(data, key):
    result = bytearray(data)
    for i in range(len(data)):
        result[i] = result[i] ^ key[i % len(key)]
    return bytes(result)

def decrypt(ciphertext, key):
    if not isinstance(ciphertext, bytes) or not isinstance(key, bytes):
        raise Exception("Ciphertext and key must be bytes!")
    if len(key) != 32 and len(key) != 64:
        raise Exception("Bad key!")
    return xor(ciphertext, key)