import base64
import subprocess

from flask import Flask, render_template, request, send_from_directory

from decryption import decrypt

app = Flask(__name__)

PROTECTED_PROGRAMS = [
    {
        "name": "Test program",
        "description": "This program just prints 'It works'",
        "key": "pIbsPhc4Yro3NtSaTmoWsA1A1YpKK85j7dmnCPgPoGc="
    },
    {
        "name": "Root lister",
        "description": "This program lists directory '/'",
        "key": "rlDG5faED8Z0hp8agxk9fee4SU9M+5YJy3mPyVVUvHY="
    },
    {
        "name": "Passwd catter",
        "description": "This program outputs contents of file '/etc/passwd'",
        "key": "1W9WjUVP/J9k0IK7H9j80ZZWRRd7m5sObATTVMEix90="
    }
]

@app.route("/")
def index():
    return render_template('index.html', programs=PROTECTED_PROGRAMS)

@app.route("/run/<int:prog_id>", methods=["POST"])
def run_program(prog_id):
    key = request.form['key']
    
    try:
        with open("programs/program" + str(prog_id), 'rb') as prog_file:
            encrypted_program = prog_file.read()
    except Exception:
        return 'Problem loading program', 500

    try:
        key_raw = base64.b64decode(key)
        program = decrypt(encrypted_program, key_raw)
    except Exception as exc:
        return str(exc), 500

    result = subprocess.run(program, shell=True, capture_output=True)
    return render_template(
        'result.html',
        out=result.stdout.decode('utf8', errors='replace'),
        err=result.stderr.decode('utf8', errors='replace')
    )

@app.route("/download/<int:prog_id>")
def download_program(prog_id):
    return send_from_directory(
        directory='programs',
        filename='program' + str(prog_id)
    )